# Copyright 2019, The TensorFlow Federated Authors.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import asyncio
import collections

from absl.testing import absltest
from absl.testing import parameterized
import tensorflow as tf

from tensorflow_federated.python.common_libs import structure
from tensorflow_federated.python.core.impl.executors import eager_tf_executor
from tensorflow_federated.python.core.impl.executors import reference_resolving_executor
from tensorflow_federated.python.core.impl.executors import sizing_executor
from tensorflow_federated.python.core.impl.tensorflow_context import tensorflow_computation
from tensorflow_federated.python.core.impl.types import computation_types


class SizingExecutorTest(parameterized.TestCase):

  def test_simple(self):
    ex = sizing_executor.SizingExecutor(eager_tf_executor.EagerTFExecutor())

    tensor_type = computation_types.TensorType(tf.int32, 10)

    @tensorflow_computation.tf_computation(tensor_type)
    def add_one(x):
      return tf.add(x, 1)

    async def _make():
      v1 = await ex.create_value(add_one)
      v2 = await ex.create_value(
          tf.constant([0, 1, 2, 3, 4, 5, 6, 7, 8, 9], tf.int32), tensor_type)
      v3 = await ex.create_call(v1, v2)
      v4 = await ex.create_struct(structure.Struct([('foo', v3)]))
      v5 = await ex.create_selection(v4, 0)
      return await v5.compute()

    asyncio.run(_make())
    self.assertCountEqual(ex.broadcast_history, [[10, tf.int32]])
    self.assertCountEqual(ex.aggregate_history, [[10, tf.int32]])

  def test_string(self):
    ex = sizing_executor.SizingExecutor(eager_tf_executor.EagerTFExecutor())
    tensor_type = computation_types.TensorType(tf.string, [4])
    strings = ['hi', 'bye', 'tensor', 'federated']
    total_string_length = sum([len(s) for s in strings])

    async def _make():
      v1 = await ex.create_value(strings, tensor_type)
      return await v1.compute()

    asyncio.run(_make())
    self.assertCountEqual(ex.broadcast_history,
                          [[total_string_length, tf.string]])
    self.assertCountEqual(ex.aggregate_history,
                          [[total_string_length, tf.string]])

  def test_different_input_output(self):
    ex = sizing_executor.SizingExecutor(eager_tf_executor.EagerTFExecutor())

    tensor_type = computation_types.TensorType(tf.int32, 10)

    @tensorflow_computation.tf_computation(tensor_type)
    def return_constant(x):
      del x
      return tf.constant(0, tf.int32)

    async def _make():
      v1 = await ex.create_value(return_constant)
      v2 = await ex.create_value([0, 1, 2, 3, 4, 5, 6, 7, 8, 9], tensor_type)
      v3 = await ex.create_call(v1, v2)
      return await v3.compute()

    asyncio.run(_make())
    self.assertCountEqual(ex.broadcast_history, [[10, tf.int32]])
    self.assertCountEqual(ex.aggregate_history, [[1, tf.int32]])

  def test_multiple_inputs(self):
    ex = sizing_executor.SizingExecutor(eager_tf_executor.EagerTFExecutor())

    int_type = computation_types.TensorType(tf.int32, 10)
    float_type = computation_types.TensorType(tf.float64, 10)

    @tensorflow_computation.tf_computation(float_type, int_type)
    def add(x, y):
      x = tf.cast(x, tf.int64)
      y = tf.cast(y, tf.int64)
      return x + y

    async def _make():
      v1 = await ex.create_value(add)
      v2 = await ex.create_value([0, 1, 2, 3, 4, 5, 6, 7, 8, 9], float_type)
      v3 = await ex.create_value([0, 1, 2, 3, 4, 5, 6, 7, 8, 9], int_type)
      v4 = await ex.create_struct(structure.Struct([(None, v2), (None, v3)]))
      v5 = await ex.create_call(v1, v4)
      return await v5.compute()

    asyncio.run(_make())
    self.assertCountEqual(ex.broadcast_history,
                          [[10, tf.int32], [10, tf.float64]])
    self.assertCountEqual(ex.aggregate_history, [[10, tf.int64]])

  def test_nested_tuple(self):
    ex = sizing_executor.SizingExecutor(eager_tf_executor.EagerTFExecutor())
    a = computation_types.TensorType(tf.int32, [4])
    b = computation_types.TensorType(tf.bool, [2])
    c = computation_types.TensorType(tf.int64, [2, 3])
    inner_type = computation_types.StructType([('a', a), ('b', b), ('c', c)])
    outer_type = computation_types.StructType([('a', inner_type),
                                               ('b', inner_type)])
    inner_type_val = collections.OrderedDict()
    inner_type_val['a'] = [0, 1, 2, 3]
    inner_type_val['b'] = [True, False]
    inner_type_val['c'] = [[1, 2, 3], [4, 5, 6]]
    outer_type_val = collections.OrderedDict()
    outer_type_val['a'] = inner_type_val
    outer_type_val['b'] = inner_type_val

    async def _make():
      v1 = await ex.create_value(outer_type_val, outer_type)
      return await v1.compute()

    asyncio.run(_make())
    self.assertCountEqual(ex.broadcast_history,
                          [[4, tf.int32], [2, tf.bool], [6, tf.int64],
                           [4, tf.int32], [2, tf.bool], [6, tf.int64]])

  def test_empty_tuple(self):
    ex = sizing_executor.SizingExecutor(eager_tf_executor.EagerTFExecutor())
    tup = computation_types.StructType([])
    empty_dict = collections.OrderedDict()

    async def _make():
      v1 = await ex.create_value(empty_dict, tup)
      return await v1.compute()

    asyncio.run(_make())
    self.assertCountEqual(ex.broadcast_history, [])

  def test_ordered_dict(self):
    a = computation_types.TensorType(tf.string, [4])
    b = computation_types.TensorType(tf.int64, [2, 3])
    tup = computation_types.StructType([('a', a), ('b', b)])
    ex = sizing_executor.SizingExecutor(eager_tf_executor.EagerTFExecutor())
    od = collections.OrderedDict()
    od['a'] = ['some', 'arbitrary', 'string', 'here']
    od['b'] = [[3, 4, 1], [6, 8, -5]]
    total_string_length = sum([len(s) for s in od['a']])

    async def _make():
      v1 = await ex.create_value(od, tup)
      return await v1.compute()

    asyncio.run(_make())
    self.assertCountEqual(ex.broadcast_history,
                          [[total_string_length, tf.string], [6, tf.int64]])

  def test_unnamed_tuple(self):
    ex = sizing_executor.SizingExecutor(eager_tf_executor.EagerTFExecutor())
    type_spec = computation_types.StructType([tf.int32, tf.int32])
    value = structure.Struct([(None, 0), (None, 1)])

    async def _make():
      v1 = await ex.create_value(value, type_spec)
      return await v1.compute()

    asyncio.run(_make())
    self.assertCountEqual(ex.broadcast_history, [[1, tf.int32], [1, tf.int32]])
    self.assertCountEqual(ex.aggregate_history, [[1, tf.int32], [1, tf.int32]])

  @parameterized.named_parameters(
      ('basic', [sizing_executor.SizingExecutor]),
      ('big_stack', [
          sizing_executor.SizingExecutor,
          reference_resolving_executor.ReferenceResolvingExecutor,
          reference_resolving_executor.ReferenceResolvingExecutor,
      ]),
      ('reference_resolving_executor', [
          sizing_executor.SizingExecutor,
          reference_resolving_executor.ReferenceResolvingExecutor,
      ]),
  )
  def test_executor_stacks(self, executor_stack):
    assert executor_stack
    ex = eager_tf_executor.EagerTFExecutor()
    for wrapping_executor in reversed(executor_stack):
      ex = wrapping_executor(ex)
    a = computation_types.TensorType(tf.int32, [4])
    b = computation_types.TensorType(tf.bool, [2])
    c = computation_types.TensorType(tf.int64, [2, 3])
    inner_type = computation_types.StructType([('a', a), ('b', b), ('c', c)])
    outer_type = computation_types.StructType([('a', inner_type),
                                               ('b', inner_type)])
    inner_type_val = collections.OrderedDict()
    inner_type_val['a'] = [0, 1, 2, 3]
    inner_type_val['b'] = [True, False]
    inner_type_val['c'] = [[1, 2, 3], [4, 5, 6]]
    outer_type_val = collections.OrderedDict()
    outer_type_val['a'] = inner_type_val
    outer_type_val['b'] = inner_type_val

    async def _make():
      v1 = await ex.create_value(outer_type_val, outer_type)
      return await v1.compute()

    asyncio.run(_make())
    self.assertCountEqual(ex.broadcast_history,
                          [[4, tf.int32], [2, tf.bool], [6, tf.int64],
                           [4, tf.int32], [2, tf.bool], [6, tf.int64]])


if __name__ == '__main__':
  absltest.main()
