# Copyright 2021, The TensorFlow Federated Authors.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Libraries for optimization algorithms."""

from tensorflow_federated.python.learning.optimizers.adagrad import build_adagrad
from tensorflow_federated.python.learning.optimizers.adam import build_adam
from tensorflow_federated.python.learning.optimizers.optimizer import check_weights_gradients_match
from tensorflow_federated.python.learning.optimizers.optimizer import handle_indexed_slices_gradients
from tensorflow_federated.python.learning.optimizers.optimizer import LEARNING_RATE_KEY
from tensorflow_federated.python.learning.optimizers.optimizer import Optimizer
from tensorflow_federated.python.learning.optimizers.rmsprop import build_rmsprop
from tensorflow_federated.python.learning.optimizers.scheduling import schedule_learning_rate
from tensorflow_federated.python.learning.optimizers.sgdm import build_sgdm
from tensorflow_federated.python.learning.optimizers.yogi import build_yogi
